/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.msViz.xnet;

import edu.msViz.xnet.dataTypes.IsotopeTrace;
import edu.msViz.xnet.dataTypes.IsotopicEnvelope;
import edu.msViz.xnet.dataTypes.TracesBundle;
import edu.msViz.xnet.probability.ProbabilityAggregator;
import java.util.List;

/**
 *
 * @author kyle
 */
public class TestRun {
    
    private TracesBundle tracesBundle;
     
    public static void main(String[] args) 
    { 
        TestRun test = new TestRun(); 
        test.tracesBundle = Utility.loadValuesFromCSV(args[0]); 
         
        List<IsotopeTrace> traces = test.tracesBundle.synthesize();
        
        try {
        	List<IsotopicEnvelope> Envelopes = (new TraceClusterer().clusterTraces(traces, ProbabilityAggregator.PROB_MODEL.BAYESIAN, null));
        	//Clustered Traces stored in Envelopes
        
        } catch (Exception ex) {
            System.err.println("ERROR || " + ex.getMessage());
            ex.printStackTrace();
        }
         
    } 
 
     
}
